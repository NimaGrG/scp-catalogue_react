import { useEffect, useState } from 'react'
import { supabase, TABLE } from '../supabaseClient.js'

function Admin() {
  const [entries, setEntries] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [itemNumber, setItemNumber] = useState('')
  const [objectClass, setObjectClass] = useState('Safe')
  const [description, setDescription] = useState('')
  const [containment, setContainment] = useState('')

  const [editingId, setEditingId] = useState(null)

  useEffect(() => {
    fetchEntries()
  }, [])

  async function fetchEntries() {
    setLoading(true)

    const { data, error } = await supabase
      .from(TABLE)
      .select('*')
      .order('item_number', { ascending: true })

    if (error) {
      setError(error.message)
    } else {
      setEntries(data)
    }

    setLoading(false)
  }

  function resetForm() {
    setItemNumber('')
    setObjectClass('Safe')
    setDescription('')
    setContainment('')
    setEditingId(null)
  }

  function handleEditClick(entry) {
    setEditingId(entry.id)
    setItemNumber(entry.item_number)
    setObjectClass(entry.object_class)
    setDescription(entry.description)
    setContainment(entry.containment_procedures)
  }

  async function handleSubmit(e) {
    e.preventDefault()

    const payload = {
      item_number: itemNumber,
      object_class: objectClass,
      description: description,
      containment_procedures: containment,
    }

    let error

    if (editingId) {
      ;({ error } = await supabase
        .from(TABLE)
        .update(payload)
        .eq('id', editingId))
    } else {
      ;({ error } = await supabase
        .from(TABLE)
        .insert([payload]))
    }

    if (error) {
      alert('Save failed: ' + error.message)
      return
    }

    resetForm()
    fetchEntries()
  }

  async function handleDelete(id) {
    const sure = confirm('Delete this record permanently?')

    if (!sure) return

    const { error } = await supabase
      .from(TABLE)
      .delete()
      .eq('id', id)

    if (error) {
      alert('Delete failed: ' + error.message)
      return
    }

    fetchEntries()
  }

  if (loading) return <p>Loading...</p>
  if (error) return <p>Error: {error}</p>

  return (
    <div>
      <h1>Admin Area</h1>

      <h2>
        {editingId ? 'Editing record' : 'Add a new record'}
      </h2>

      <form onSubmit={handleSubmit}>
        <input
          placeholder="Item number (e.g. SCP-022)"
          value={itemNumber}
          onChange={(e) => setItemNumber(e.target.value)}
          required
        />

        <select
          value={objectClass}
          onChange={(e) => setObjectClass(e.target.value)}
        >
          <option>Safe</option>
          <option>Euclid</option>
          <option>Keter</option>
          <option>Thaumiel</option>
        </select>

        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />

        <textarea
          placeholder="Containment procedures"
          value={containment}
          onChange={(e) => setContainment(e.target.value)}
        />

        <button type="submit">
          {editingId ? 'Save changes' : 'Add record'}
        </button>

        {editingId && (
          <button type="button" onClick={resetForm}>
            Cancel
          </button>
        )}
      </form>

      <h2>{entries.length} records found</h2>

      <ul>
        {entries.map((entry) => (
          <li key={entry.id}>
            <strong>{entry.item_number}</strong>{' '}
            ({entry.object_class}) — {entry.description}

            <button onClick={() => handleEditClick(entry)}>
              Edit
            </button>

            <button onClick={() => handleDelete(entry.id)}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default Admin
