import { useEffect, useState } from 'react'
import { supabase, TABLE } from '../supabaseClient.js'

function Catalogue() {
  const [entries, setEntries] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchEntries()
  }, [])

  async function fetchEntries() {
    setLoading(true)

    const { data, error } = await supabase
      .from(TABLE)
      .select('*')
      .order('item_number', { ascending: true })

    if (error) {
      setError(error.message)
    } else {
      setEntries(data)
    }

    setLoading(false)
  }

  if (loading) return <p>Loading catalogue...</p>

  if (error) return <p>Error: {error}</p>

  return (
    <div>
      <h1>SCP Catalogue</h1>

      <h2>{entries.length} records found</h2>

      {entries.length === 0 ? (
        <p>No SCP records found.</p>
      ) : (
        <ul>
          {entries.map((entry) => (
            <li key={entry.id}>
              <strong>{entry.item_number}</strong>
              {' '}
              ({entry.object_class})

              <p>
                {entry.description}
              </p>

              <p>
                <strong>Containment Procedures:</strong>
                {' '}
                {entry.containment_procedures}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

export default Catalogue
