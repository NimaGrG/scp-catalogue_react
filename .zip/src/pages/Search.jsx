import { useEffect, useState } from 'react'
import { supabase, TABLE } from '../supabaseClient.js'

function Search() {
  const [entries, setEntries] = useState([])
  const [searchText, setSearchText] = useState('')
  const [objectClass, setObjectClass] = useState('All')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchEntries()
  }, [])

  async function fetchEntries() {
    setLoading(true)

    const { data, error } = await supabase
      .from(TABLE)
      .select('*')
      .order('item_number', { ascending: true })

    if (error) {
      setError(error.message)
    } else {
      setEntries(data)
    }

    setLoading(false)
  }

  const filteredEntries = entries.filter((entry) => {
    const text = searchText.toLowerCase()

    const matchesText =
      entry.item_number.toLowerCase().includes(text) ||
      entry.description.toLowerCase().includes(text)

    const matchesClass =
      objectClass === 'All' ||
      entry.object_class === objectClass

    return matchesText && matchesClass
  })

  if (loading) {
    return <p>Loading...</p>
  }

  if (error) {
    return <p>Error: {error}</p>
  }

  return (
    <div>
      <h1>Search SCP Catalogue</h1>

      <div>
        <input
          type="text"
          placeholder="Search SCP number or description..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
        />

        <select
          value={objectClass}
          onChange={(e) => setObjectClass(e.target.value)}
        >
          <option>All</option>
          <option>Safe</option>
          <option>Euclid</option>
          <option>Keter</option>
        </select>
      </div>

      <h2>
        {filteredEntries.length} records found
      </h2>

      {filteredEntries.length === 0 ? (
        <p>No matching SCP records found.</p>
      ) : (
        <ul>
          {filteredEntries.map((entry) => (
            <li key={entry.id}>
              <strong>{entry.item_number}</strong>
              {' '}
              ({entry.object_class})

              <p>
                {entry.description}
              </p>

              <p>
                <strong>Containment Procedures:</strong>
                {' '}
                {entry.containment_procedures}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

export default Search
