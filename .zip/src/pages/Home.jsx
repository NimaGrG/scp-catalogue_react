function Home() {
  return (
    <div>
      <h1>SCP Catalogue</h1>

      <p>Welcome to the SCP Foundation Secure Archive.</p>

      <p>
        Browse SCP records, search the catalogue, or manage records
        through the admin area.
      </p>
    </div>
  )
}

export default Home
