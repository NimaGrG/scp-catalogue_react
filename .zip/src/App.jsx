import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css'
import Navbar from './components/navbar.jsx'
import Home from './pages/Home.jsx'
import Catalogue from './pages/Catalogue.jsx'
import Search from './pages/Search.jsx'
import Admin from './pages/Admin.jsx'

function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <main>
        <Routes>
          <Route path="/" element={<Home />} />

          <Route
            path="/catalogue"
            element={<Catalogue />}
          />

          <Route
            path="/search"
            element={<Search />}
          />

          <Route
            path="/admin"
            element={<Admin />}
          />
        </Routes>
      </main>
    </BrowserRouter>
  )
}

export default App
