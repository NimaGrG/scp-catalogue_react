import { Link } from 'react-router-dom'

function Navbar() {
  return (
    <nav>
      <h2>SCP Catalogue</h2>

      <Link to="/">Home</Link>
      {' | '}
      <Link to="/catalogue">SCP Catalogue</Link>
      {' | '}
      <Link to="/search">Search / Filter</Link>
      {' | '}
      <Link to="/admin">Admin Area</Link>
    </nav>
  )
}

export default Navbar

